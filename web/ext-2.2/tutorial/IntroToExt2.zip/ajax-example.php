<?php if(isset($_POST['name'])) {
		echo 'From Server: '.$_POST['name'];
	}
?>